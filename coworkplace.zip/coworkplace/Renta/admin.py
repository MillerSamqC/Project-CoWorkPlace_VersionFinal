from django.contrib import admin
from Renta.models import *

# Register your models here.
admin.site.register(Reserva)
admin.site.register(Pago)
